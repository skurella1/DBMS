<?php

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if($connect){
        
    }

    if(isset($_POST['signin']))
    {
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM `student` WHERE `student_email` = '$email' AND `student_password` = '$password'";
        $result = mysqli_query($connect, $sql);
        if(mysqli_num_rows($result) > 0)
        {
            $row = mysqli_fetch_assoc($result);
            session_unset();
            session_destroy();
            session_start();
            session_regenerate_id();
            $_SESSION['student_id'] = $row['student_id'];
            $_SESSION['student_name'] = $row['student_name'];
            $_SESSION['student_email'] = $row['student_email'];
            $_SESSION['student_password'] = $row['student_password'];
            $_SESSION['student_phone'] = $row['student_phone'];
            header("Location: ../student/index.php");
        }
        else
        {
            echo "<font color='red'><p>Email and password is invalid!</p></font>";
        }
    }

?>

<html>
<head>
    <title>LMS - Sign in</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <!--Write sign in form-->
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Sign in as Student</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        
      </nav>
    </header>
    <br/><br/>
    <div class="container px-4">
    <p><a href="../common/index.php"><< Go Back</a></p>
    <form action="signin.php" method="post">
        <div class="mb-3">
        <label for="email" class="form-label">Email address</label>
        <input type="email" name="email" class="form-control" placeholder="yourid@website.com" required><br/>
        </div>
        <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Password" required><br/>
        </div>
        <input type="submit" class="form-control btn btn-primary" name="signin" value="Sign In">
    </form>
    <p>Don't have an account? <a href="register.php">Register</a></p>
    </div>
</body>
</html>