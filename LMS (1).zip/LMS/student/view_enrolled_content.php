<?php
    session_start();
    
    if(!isset($_SESSION['student_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['content_id']) && !isset($_GET['course_id']))
    {
        header("Location: browse_courses.php");
    }

    $content_id = $_GET['content_id'];
    $course_id = $_GET['course_id'];

    if(isset($_GET['is_content_completed']))
    {
        $is_content_completed = $_GET['is_content_completed'];
        change_status_content_completed($content_id);
    }

    function get_student_enrolled_content($content_id)
    {
        global $connect;
        $sql = "SELECT * FROM `student_enrolled_course_content` WHERE `student_id` = ".$_SESSION['student_id']." AND `course_content_id` = ".$content_id;
        $result = mysqli_query($connect, $sql);
        if(mysqli_num_rows($result) > 0)
        {
            $content_data = array();
            while($row = mysqli_fetch_assoc($result))
            {
                $content_data[] = $row;
            }
            get_particular_content($content_data[0]);
        }
        else
        {
            echo "<h3>Content not found!</h3>";
        }
    }

    function get_particular_content($content_data)
    {
        global $connect;
        $id = $content_data['course_content_id'];
        $sql = "SELECT * FROM `course_content` WHERE `content_id` = '$id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $content = mysqli_fetch_assoc($result);
                $content_id = $content['content_id'];
                $content_name = $content['content_name'];
                $content_desc = $content['theory_notes'];
                $is_content_for_free = $content['is_content_available_for_free_access'];
                $content_video = $content['content_video_material'];
                $course_id = $content['associated_with_course'];
                ?>
                
                <div class="row">
                <div class="content-view-container" >
                    <div class="col" style="width:50%; float:left">
                        <div class="card" style="padding:7px">
                                <video width="100%" height="350px" class="card-top-img" id="content_video" controls>
                                    <source src="<?php echo $content_video; ?>" type="video/mp4">
                                    <source src="<?php echo $content_video; ?>" type="video/mov">
                                </video>
                            <h2><?php echo $content_name; ?></h2>
                            <p>
                                <a href="view_content_quiz.php?content_id=<?php echo $content_id;?>"><i class="fa fa-book">   View Quiz</i></a>
                            </p>
                        </div>
                    </div>
                    <div class="col" style="width:50%; float:right;">
                        <div class="card" style="padding:15px;">
                            <div class="theory-notes">
                                <h3>Theory Notes</h3>
                                <p><?php echo $content_desc; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <?php
            }
            else
            {
                echo "No content found";
            }
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function change_status_content_completed($content_id)
    {
        global $connect;
        global $course_id;
        $sql = "UPDATE `student_enrolled_course_content` SET `is_completed` = 1 WHERE `student_id` = ".$_SESSION['student_id']." AND `course_content_id` = ".$content_id;
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            increase_course_content_watch_count($course_id);
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function increase_course_content_watch_count($course_id)
    {
        global $connect;
        $sql = "UPDATE `student_enrolled_course` SET `course_content_watched_count` = `course_content_watched_count` + 1 WHERE `course_id` = ".$course_id." AND `student_id` = ".$_SESSION['student_id'];
        $result = mysqli_query($connect, $sql);
        if($result)
        {
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <title>View Content</title>
        <link rel="stylesheet" href="../common/grid_layout.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="../styles/styles.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>View Course Content</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back to Home</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
        <div class="container">
            <div class="container">

            <?php
                        get_student_enrolled_content($content_id);
                    ?>
                </div>
                
            </div>
        </div>
    </body>
    <script type="text/javascript">
        document.getElementById('content_video').addEventListener('ended',videoEndHandler,false);
        function videoEndHandler(e) {
            window.location.href = "view_enrolled_content.php?content_id="+<?php echo $content_id; ?>+"&course_id="+<?php echo $course_id; ?>+"&is_content_completed=1";
        }
    </script>
</html>