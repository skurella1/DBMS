<?php

    session_start();
    
    if(!isset($_SESSION['student_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['course_id']))
    {
        header("Location: browse_courses.php");
    }

    $course_id = $_GET['course_id'];
    $teacher_id;
    $pricing;
    
    if(empty($_SESSION['content_ids']))
    {
        $course_content_ids = array();
    }
    else
    {
        $course_content_ids = $_SESSION['content_ids'];
    }

    if(empty($_SESSION['content_quiz_ids']))
    {
        $course_content_quiz_ids = array();
    }
    else
    {
        $course_content_quiz_ids = $_SESSION['content_quiz_ids'];
    }
    
    if(isset($_POST['enroll_course']))
    {
        $teacher_id = $_POST['teacher_id'];
        $pricing = $_POST['price'];
        enroll_student($course_id, $teacher_id);
        header("Location: payment_course.php?course_id=".$course_id."&teacher_id=".$teacher_id."&price=".$pricing);
    }

    function get_current_selected_course($course_id)
    {
        global $connect;
        global $teacher_id;
        global $pricing;
        $sql = "SELECT * FROM `courses` WHERE `course_id` = ".$course_id;
        $result_course = mysqli_query($connect, $sql);
        if(mysqli_num_rows($result_course) > 0)
        {
            $row = mysqli_fetch_assoc($result_course);
            echo "<img src='".$row['course_image']."' class='img-thumbnail' alt='Course Image'>";
            echo "<h3>".$row['course_name']."</h3>";
            echo "<p>".$row['course_desc']."</p>";
            echo "<p>Price: ".$row['course_price']."</p>";
            echo "<p>Discount Price: ".$row['course_discount_price']."</p>";
            echo "<p>Start Date: ".$row['course_start_date']."</p>";
            echo "<p>End Date: ".$row['course_end_date']."</p>";
            $teacher_id = $row['created_by_teacher_id'];
            $pricing = $row['course_discount_price'];
            echo "<p>Created by: ".get_teacher_name($row['created_by_teacher_id'])."</p>";
        }
        else
        {
            echo "<p>Course not found!</p>";
        }
    } 
    
    function get_teacher_name($teacher_id)
    {
        global $connect;
        $sql = "SELECT `teacher_name` FROM `teacher` WHERE `teacher_id` = '$teacher_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            $row = mysqli_fetch_assoc($result);
            return $row['teacher_name'];
        }
        else
        {
            return "Error: ".mysqli_error($connect);
        }
    }

    function get_course_content($course_id)
    {
        global $connect;
        global $course_content_ids;
        $sql = "SELECT * FROM `course_content` WHERE `associated_with_course` = ".$course_id;
        $result = mysqli_query($connect, $sql);
        if(mysqli_num_rows($result) > 0)
        {
            echo "<div class='grid-container'>";
            for($i = 0; $i < mysqli_num_rows($result); $i++)
            {
                
                echo "<div class='row'>";
                $row = mysqli_fetch_assoc($result);
                $course_content_ids[$i] = $row['content_id'];
                $_SESSION['content_ids'] = $course_content_ids;
                $content_url = $row['content_video_material'];
                get_content_quiz($row['content_id']);
                echo "<div class='column'>";
                if($row['is_content_available_for_free_access'])
                {
                    echo "<video width='320px' height='180px' controls>
                            <source src=$content_url type='video/mp4'>
                            <source src=$content_url type='video/mov'>
                        </video>";
                }
                else
                {
                    echo "<video width='320px' height='120px'>
                            <source src=$content_url type='video/mp4'>
                            <source src=$content_url type='video/mov'>
                        </video>";
                }
                echo "<h3>".$row['content_name']."</h3>";
                echo "<p>".$row['theory_notes']."</p>";
                echo "</div>";
                echo "</div>";
            }
            echo "</div>";
        }
        else
        {
            echo "<p>No content available!</p>";
        }
    }

    function get_content_quiz($content_id)
    {
        global $connect;
        $sql = "SELECT * FROM `course_content_quiz` WHERE `asscociated_with_course_content` = ".$content_id;
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            for($i = 0; $i < mysqli_num_rows($result); $i++)
            {
                $row = mysqli_fetch_assoc($result);
                $course_content_quiz_ids[$i] = $row['quiz_id'];
                $_SESSION['content_quiz_ids'] = $course_content_quiz_ids;
                
            }
        }
        else
        {
            echo "<p>No quiz available!</p>";
        }
    }

    function enroll_student($course_id, $teacher_id)
    {
        global $connect;
        global $course_content_ids;
        $student_id = $_SESSION['student_id'];
        $sql = "INSERT INTO `student_enrolled_course`(`student_id`, `course_id`, `teacher_id`, `is_active`) VALUES ('$student_id', '$course_id', '$teacher_id', 1)";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            $success = false;
            for($i = 0; $i < count($course_content_ids); $i++)
            {
                $content_sql = "INSERT INTO `student_enrolled_course_content`(`student_id`, `course_content_id`, `is_completed`)
                            VALUES ('$student_id', '$course_content_ids[$i]', 0)";
                $content_result = mysqli_query($connect, $content_sql);
                if($content_result)
                {
                    $success = true;
                }
                else
                {
                    $success = false;
                    echo "Error: ".mysqli_error($connect);
                }
            }
            
            if($success)
            {
                enroll_student_quiz();
                
            }
            else
            {
                echo "<p>Enrollment failed!</p>";
                echo "Error: ".mysqli_error($connect);
            }
        }
        else
        {
            echo "<p>Enrollment failed!</p>";
            echo "<p>Error: ".mysqli_error($connect)."</p>";
        }
    }

    function enroll_student_quiz()
    {
        global $connect;
        global $course_content_quiz_ids;
        $student_id = $_SESSION['student_id'];
        $success = false;
        for($i = 0; $i < count($course_content_quiz_ids); $i++)
        {
            $content_id = $course_content_quiz_ids[$i];
            $quiz_sql = "INSERT INTO `student_enrolled_quiz`(`student_id`, `content_quiz_id`, `is_completed`)
                        VALUES ('$student_id', '$content_id', 0)";
            $quiz_result = mysqli_query($connect, $quiz_sql);
            if($quiz_result)
            {
                $success = true;
            }
            else
            {
                $success = false;
                echo "Error: ".mysqli_error($connect);
            }
        }
        
        if($success)
        {
            echo '<script>
                alert("Course Quiz successfully!");
                window.location.href = "browse_courses.php";
                </script>';
        }
        else
        {
            echo "<p>Enrollment failed!</p>";
            echo "Error: ".mysqli_error($connect);
        }
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Enroll Course</title>
        <link rel="stylesheet" href="../common/modal_layout.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <link rel="stylesheet" href="../styles/styles.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    </head>
    <body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Enroll Course</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back to Home</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
        <div class="container">
            <div class="">
                <div class="card container px-4" style="width: 50%;float:left;padding:7px">
                
                    <div class="row gx-5">
                        <div class="col">
                        <?php get_current_selected_course($course_id); ?>
                        <form action="enroll_course.php?course_id=<?php echo $course_id; ?>" method="POST">
                            <input type="hidden" name="price" value="<?php echo $pricing; ?>">
                            <input type="hidden" name="teacher_id" value="<?php echo $teacher_id; ?>">
                            <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
                            <input type="submit" class="form-control btn btn-primary" name="enroll_course" value="Enroll Now">
                        </form>
                        </div>
                    </div>
                </div>
                <div class="card container px-4" style="width: 40%;float:right;">
                    <div class="row gx-5">
                    <div class="col">
                        <?php 
                            get_course_content($course_id);
                        ?>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <script>
        var modal = document.getElementById("myModal");
        var span = document.getElementsByClassName("close")[0];
        modal.style.display = "none";
        span.onclick = function() {
            modal.style.display = "none";
        }
        
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</html>