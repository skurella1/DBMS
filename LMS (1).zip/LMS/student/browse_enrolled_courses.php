<?php

    session_start();
    
    if(!isset($_SESSION['student_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    function get_student_enrolled_courses()
    {
        global $connect;
        $sql = "SELECT * FROM `student_enrolled_course` WHERE `student_id` = ".$_SESSION['student_id'];
        $result = mysqli_query($connect, $sql);
        if(mysqli_num_rows($result) > 0)
        {
            $course_ids = array();
            while($row = mysqli_fetch_assoc($result))
            {
                $course_ids[] = $row['course_id'];
            }
            browse_available_courses($course_ids);
        }
        else
        {
            echo "<h3>No courses enrolled yet!</h3>";
        }
    }

    function browse_available_courses($course_ids)
    {
        global $connect;
        if(count($course_ids) > 0)
        {
            echo "<div class='grid-container'>";
            for($i = 0; $i < count($course_ids); $i++)
            {
                $sql = "SELECT * FROM `courses` WHERE `course_id` = ".$course_ids[$i];
                $result_courses = mysqli_query($connect, $sql);
                $row_count = 0;
                if(mysqli_num_rows($result_courses) > 0)
                {
                    
                    
                    if($i % 2 == 2)
                    {
                        echo "<div class='row'>";
                        $row_count++;
                    }
                    $row = mysqli_fetch_assoc($result_courses);
                    echo "<div class='column'>";
                    echo "<div class='card' style='padding:7px'>";
                    echo "<img src='".$row['course_image']."' class='card-img-top img-fluid' alt='Course Image'>";
                    echo "<h3 class='card-title'>".$row['course_name']."</h3>";
                    echo "<p class='card-text'>".$row['course_desc']."</p>";
                    echo "<p>Price: ".$row['course_price']."</p>";
                    echo "<p>Discount Price: ".$row['course_discount_price']."</p>";
                    echo "<p>Start Date: ".$row['course_start_date']."</p>";
                    echo "<p>End Date: ".$row['course_end_date']."</p>";
                    echo "<p>Created by: ".get_teacher_name($row['created_by_teacher_id'])."</p>";
                    echo "<p><a href='view_enrolled_course.php?course_id=".$row['course_id']."'>View Course</a></p>";
                    echo "</div>";
                    echo "</div>";
                    echo "</div>";
                    if($i % 2 == 2)
                    {
                        echo "</div>";
                    }
                    
                }
                
            }
            echo "</div>";
        }
        else
        {
            echo "<h3>No Enrolled courses available!</h3>";
        }
    }

    function get_teacher_name($teacher_id)
    {
        global $connect;
        $sql = "SELECT `teacher_name` FROM `teacher` WHERE `teacher_id` = '$teacher_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            $row = mysqli_fetch_assoc($result);
            return $row['teacher_name'];
        }
        else
        {
            return "Error: ".mysqli_error($connect);
        }
    }

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../styles/grid_layout.css">
    <link type="stylesheet" href="../styles/common_layout.css">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <title>LMS - Browse Courses</title>
</head>
<script type="text/javascript" src="../scripts/course_view.js"></script>
<body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>My Enrolled Courses</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back to Home</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
    <div class="container">
    <div class="grid-list-option">
        <p>View as:</p>
        <button class="btn" id="list-view" onclick="listView()"><i class="fa fa-bars"></i> List</button>
        <button class="btn" id="grid-view" onclick="gridView()"><i class="fa fa-th-large"></i> Grid</button>
    </div>
    <br/>
    <br/>
    <div class="container-fluid">
    <?php
        get_student_enrolled_courses();
    
    ?>
    </div>
    </div>
</body>
</html>