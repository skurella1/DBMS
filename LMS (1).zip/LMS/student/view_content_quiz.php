<?php

    session_start();
    
    if(!isset($_SESSION['student_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['content_id']))
    {
        header("Location: browse_courses.php");
    }

    $content_id = $_GET['content_id'];

    function get_course_content_quiz()
    {
        global $connect;
        global $content_id;

        $sql = "SELECT * FROM `course_content_quiz` WHERE `asscociated_with_course_content` = '$content_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                return $result;
            }
            else
            {
                echo "<h2>No Quiz Found!</h2>";
            }
        }
    }

    function student_enrolled_quiz($quiz_id)
    {
        global $connect;
        $sql = "SELECT * FROM `student_enrolled_quiz` WHERE `student_id` = ".$_SESSION['student_id']." AND `content_quiz_id` = ".$quiz_id;
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                return $result;
            }
            else
            {
                return "<p>No Data available!</p>";
            }
        }
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>LMS - View Quiz List</title>
        <link type="stylesheet" href="../styles/common_layout.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <link rel="stylesheet" href="../styles/styles.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    </head>
    <script type="text/javascript">
        function delete_confirmation(quiz_id, content_id)
        {
            var confirmation = confirm("Are you sure you want to delete this quiz?");
            if(confirmation)
            {
                window.location.href = "delete_quiz.php?quiz_id="+quiz_id+"&content_id"+content_id;
            }
        }
    </script>
    <body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Quiz List</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back to Home</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
        <div class="container">
        <div class="container">
        <table class="table">
            <tr>
                <th>Quiz Name</th>
            </tr>
            <?php
                $quiz_list = get_course_content_quiz();
                if($quiz_list)
                {
                    $count = 1;
                    while($quiz = mysqli_fetch_assoc($quiz_list))
                    {
                        $quiz_id = $quiz['quiz_id'];
                        echo "<tr>";
                        echo "<td>Quiz - ".$count."</td>";
                        $enrolled_quiz = student_enrolled_quiz($quiz_id);
                        if($enrolled_quiz)
                        {
                            echo "<tr>";
                            while($student_quiz = mysqli_fetch_assoc($enrolled_quiz))
                            {
                               
                                $status = ($student_quiz['is_completed'] == 1) ? "Completed" : "Pending";
                                echo "<td>Is Completed ".$status."</td>";
                                
                                echo "<td>Number of attempts ".$student_quiz['number_of_attempts']."</td>";
                               
                            }
                            echo "</tr>";
                        }
                        echo "<td><a href='student_quiz.php?quiz_id=$quiz_id&question_no=0'>View Quiz</a></td>";
                        echo "</tr>";

                        $count++;
                    }
                }
            ?>
        </table>
        </div>
        </div>
    </body>
</html>
