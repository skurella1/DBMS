<?php

    session_start();
    
    if(!isset($_SESSION['student_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['course_id']) && !isset($_GET['teacher_id']) && !isset($_GET['price']))
    {
        header("Location: browse_courses.php");
    }

    if(empty($_SESSION['content_ids']))
    {
        $course_content_ids = array();
    }
    else
    {
        $course_content_ids = $_SESSION['content_ids'];
    }

    if(empty($_SESSION['content_quiz_ids']))
    {
        $course_content_quiz_ids = array();
    }
    else
    {
        $course_content_quiz_ids = $_SESSION['content_quiz_ids'];
    }

    $course_id = $_GET['course_id'];
    $teacher_id = $_GET['teacher_id'];
    $price = $_GET['price'];
    

    if(isset($_POST['pay']))
    {
        if(add_into_payment($course_id, $teacher_id))
        {
            enroll_student($course_id, $teacher_id);
        }
    }

    function get_course_content($course_id)
    {
        global $connect;
        global $course_content_ids;
        $sql = "SELECT * FROM `course_content` WHERE `associated_with_course` = ".$course_id;
        $result = mysqli_query($connect, $sql);
        if(mysqli_num_rows($result) > 0)
        {
            for($i = 0; $i < mysqli_num_rows($result); $i++)
            {
                
                $row = mysqli_fetch_assoc($result);
                $course_content_ids[$i] = $row['content_id'];
                $_SESSION['content_ids'] = $course_content_ids;
                get_content_quiz($row['content_id']);
            }
        }
        else
        {
            echo "<p>No content available!</p>";
        }
    }

    function get_content_quiz($content_id)
    {
        global $connect;
        $sql = "SELECT * FROM `course_content_quiz` WHERE `asscociated_with_course_content` = ".$content_id;
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            for($i = 0; $i < mysqli_num_rows($result); $i++)
            {
                $row = mysqli_fetch_assoc($result);
                $course_content_quiz_ids[$i] = $row['quiz_id'];
                $_SESSION['content_quiz_ids'] = $course_content_quiz_ids;
                
            }
        }
        else
        {
            echo "<p>No quiz available!</p>";
        }
    }

    function add_into_payment($course_id, $teacher_id)
    {
        global $connect;
        $sql = "INSERT INTO `payment`(`student_id`, `course_id`, `teacher_id`, `payment_status`) VALUES (".$_SESSION['student_id'].", '$course_id', '$teacher_id', 'paid')";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    function enroll_student($course_id, $teacher_id)
    {
        global $connect;
        global $course_content_ids;
        $student_id = $_SESSION['student_id'];
        $sql = "INSERT INTO `student_enrolled_course`(`student_id`, `course_id`, `teacher_id`, `is_active`) VALUES ('$student_id', '$course_id', '$teacher_id', 1)";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            $success = false;
            for($i = 0; $i < count($course_content_ids); $i++)
            {
                $content_sql = "INSERT INTO `student_enrolled_course_content`(`student_id`, `course_content_id`, `is_completed`)
                            VALUES ('$student_id', '$course_content_ids[$i]', 0)";
                $content_result = mysqli_query($connect, $content_sql);
                if($content_result)
                {
                    $success = true;
                }
                else
                {
                    $success = false;
                    echo "Error: ".mysqli_error($connect);
                }
            }
            
            if($success)
            {
                enroll_student_quiz();
                
            }
            else
            {
                echo "<p>Enrollment failed!</p>";
                echo "Error: ".mysqli_error($connect);
            }
        }
        else
        {
            echo "<p>Enrollment failed!</p>";
            echo "<p>Error: ".mysqli_error($connect)."</p>";
        }
    }

    function enroll_student_quiz()
    {
        global $connect;
        global $course_content_quiz_ids;
        $student_id = $_SESSION['student_id'];
        $success = false;
        for($i = 0; $i < count($course_content_quiz_ids); $i++)
        {
            $content_id = $course_content_quiz_ids[$i];
            $quiz_sql = "INSERT INTO `student_enrolled_quiz`(`student_id`, `content_quiz_id`, `is_completed`)
                        VALUES ('$student_id', '$content_id', 0)";
            $quiz_result = mysqli_query($connect, $quiz_sql);
            if($quiz_result)
            {
                $success = true;
            }
            else
            {
                $success = false;
                echo "Error: ".mysqli_error($connect);
            }
        }
        
        if($success)
        {
            echo '<script>
                alert("Course enrolled successfully!");
                window.location.href = "browse_courses.php";
                </script>';
        }
        else
        {
            echo "<p>Enrollment failed!</p>";
            echo "Error: ".mysqli_error($connect);
        }
    }

?>
<html>
    <head>
        <title>LMS - Payment Course</title>
        <link type="stylesheet" href="../styles/common_layout.css">
        <script src="../tinymce/tinymce.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script type="text/javascript" src="../scripts/text_editor.js"></script>
        <script type="text/javascript" src="../scripts/image_preview.js"></script>
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <style>
            body {
                display: flex;
                flex-direction: column;
                margin-top: 1%;
                justify-content: center;
                align-items: center;
            }
    
            #rowAdder {
                margin-left: 17px;
        }
    </style>
    </head>
    <body>
        <!---payment form-->
        <div class="container">
            <div class="container">
                <h2>Pay for course</h2>
                <form action="payment_course.php?course_id=<?php echo $course_id?>&teacher_id=<?php echo $teacher_id?>&price=<?php echo $price?>" method="post">
                    <div class="form-group">
                        <label for="card_number">Card Number</label>
                        <input type="number" class="form-control" name="card_number" placeholder="Enter card number" required>
                        <br/><br/>
                        <label for="card_number">Price to Pay</label>
                        <input type="text" class="form-control"  name="price_paid" value="<?php echo $price; ?>" readonly>
                        <br/><br/>
                        <input type="submit" class="form-control btn btn-primary" name="pay" value="Pay"><br/><br/>
                        <a href="browse_courses.php" class="form-control btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>