<?php



    function upload_course_thumbnail($file_name, $file_tmp_name, $file_size, $file_error, $file_type)
    {
        $file_ext = strtolower(pathinfo($file_name,PATHINFO_EXTENSION));
        $file_actual_ext = strtolower($file_ext);
        $allowed = array('jpg', 'jpeg', 'png');
        if($file_actual_ext == "jpg" || $file_actual_ext == "png" || $file_actual_ext == "jpeg")
        {
            if($file_error === 0)
            {
                if($file_size < 1000000)
                {
                    $file_new_name = uniqid('', true).".".$file_actual_ext;
                    $file_destination = '../uploads/course_thumbnails/'.$file_new_name;
                    move_uploaded_file($file_tmp_name, $file_destination);
                    return $file_destination;
                }
                else
                {
                    echo "Your file is too big!";
                    return "error";
                }
            }
            else
            {
                echo "There was an error uploading your file!";
                return "error";
            }
        }
        else
        {
            echo "You cannot upload files of this type!";
            return "error";
        }
    }

    function upload_content_video($file_name, $file_tmp_name, $file_size, $file_error, $file_type)
    {
        $file_ext = strtolower(pathinfo($file_name,PATHINFO_EXTENSION));
        $file_actual_ext = strtolower($file_ext);
        $allowed = array('jpg', 'jpeg', 'png');
        if($file_actual_ext == "mp4" || $file_actual_ext == "mov" || $file_actual_ext == "avi")
        {
            if($file_error === 0)
            {
                if($file_size < 100000000)
                {
                    $file_new_name = uniqid('', true).".".$file_actual_ext;
                    $file_destination = '../uploads/course_content_videos/'.$file_new_name;
                    move_uploaded_file($file_tmp_name, $file_destination);
                    return $file_destination;
                }
                else
                {
                    echo "Your file is too big!";
                    return "error";
                }
            }
            else
            {
                echo "There was an error uploading your file!";
                return "error";
            }
        }
        else
        {
            echo "You cannot upload files of this type!";
            return "error";
        }
    }

?>