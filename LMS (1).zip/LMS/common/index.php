<!DOCTYPE html>
<html>
<head>
    <title>LMS - Home</title>
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<body>
    <!--Write sign in form-->
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><b>LMS</b></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="roleselection.php">Sign In</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="roleselection.php">Sign Up</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/><br/>
    <main role="main" class="container">
      <h1 class="mt-5">The <font color="orange">easy-to-use</font> <font color="blue">LMS</font> that sets you up for <font color="green">success</font></h1>
      <p class="lead">Skills for your present (and your future). Get started with us.</p>
      <img src="../images/graphic-1.jpeg" class="img-thumbnail">
    </main>
</body>
</html>