

tinymce.init({
    selector: '#text-editor',
    width: 750,
    height: 250
});
CKEDITOR.replace('text-editor');