<?php
    header("Location: common/index.php");
?>