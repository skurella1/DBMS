<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }
    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }
    $_SESSION['course_id'] = 0;

    if(!isset($_GET['quiz_id']))
    {
        header("Location: create_quiz_item.php");
    }

    $quiz_id = $_GET['quiz_id'];

    if(isset($_POST['create_quiz']))
    {
        add_quiz_question($quiz_id);
    }

    function add_quiz_question($quiz_id)
    {
        global $connect;
        $question_text = $_POST['quiz_question'];
        $associated_with_quiz = $quiz_id;

        $sql = "INSERT INTO `quiz_question`(`question_text`, `associated_quiz_id`) VALUES ('$question_text', '$associated_with_quiz')";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            $sql = "SELECT `question_id` FROM `quiz_question` ORDER BY `question_id` DESC LIMIT 1";
            $result = mysqli_query($connect, $sql);
            if($result)
            {
                $row = mysqli_fetch_assoc($result);
                $ques_id = $row['question_id'];
                add_quiz_answers($ques_id, $quiz_id);
            }
            else
            {
                echo "Error: ".mysqli_error($connect);
            }
        }
        else
        {
            echo "<script>alert('Error Adding Question!');</script>";
        }

    }

    function add_quiz_answers($question_id, $quiz_id)
    {
        global $connect;
        $options = $_POST['answer_option'];
        $answers_tick = $_POST['answer'];
        $associated_with_question = $question_id;
        $stored_succesfully = false;
        for($i = 0; $i < count($options); $i++)
        {
            $answer_text = $options[$i];
            $is_correct = isset($answers_tick[$i]) ? 1 : 0;
            $sql = "INSERT INTO `quiz_answer`(`option_text`, `is_correct_option`, `associated_with_question`, `associated_quiz_id`) VALUES ('$answer_text', '$is_correct', '$associated_with_question', '$quiz_id')";
            $result = mysqli_query($connect, $sql);
            if($result)
            {
                $stored_succesfully = true;
            }
            else
            {
                $stored_succesfully = false;
                echo "Error Adding Answers: ".mysqli_error($connect);
            }
        }

        if($stored_succesfully)
        {
            echo "<script>alert('Quiz Created Successfully!');</script>";
        }
        else
        {
            echo "<script>alert('Error Creating Quiz!');</script>";
        }

    }

?>

<!DOCTYPE html>
<html>
    <head>
        <title>LMS - Create QUIZ</title>
        <link type="stylesheet" href="../styles/common_layout.css">
        <script src="../tinymce/tinymce.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script type="text/javascript" src="../scripts/text_editor.js"></script>
        <script type="text/javascript" src="../scripts/image_preview.js"></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="../styles/styles.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <style>
            body {
                display: flex;
                flex-direction: column;
                margin-top: 1%;
                justify-content: center;
                align-items: center;
            }
    
            #rowAdder {
                margin-left: 17px;
        }
    </style>
    </head>
    <body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Create Quiz for content</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back To Dashboard</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <div class="container">
        <form action="create_quiz.php?quiz_id=<?php echo $quiz_id;?>" method="post" enctype="multipart/form-data">
            <label for="quiz_question"><b>Quiz Question</b></label>
            <textarea rows = "5" cols = "60" name = "quiz_question" id="text-editor"></textarea>
            <br/>
            <div class="">
                <div class="col-lg-12">
                    <div id="row">
                        <div id="row">
                            <label for="answer_option"><b>Answer Option</b></label>
                            <input type="text" name="answer_option[]" class="form-control m-input" required>
                            <br/>
                            <label for="answer"><b>Is Correct Answer?</b></label> 
                            <input type="checkbox" id="check1" name="answer">
                            <button class="btn btn-danger"
                                    id="DeleteRow" type="button">
                                    <i class="bi bi-trash"></i>
                                    Delete
                            </button>
                            
                        </div>
                    </div>
 
                    <div id="newinput"></div>
                    <br/><br/>
                    <button id="rowAdder" type="button"
                        class="btn btn-dark">
                        <span class="bi bi-plus-square-dotted">
                        </span> Add Option
                    </button>
                </div>
            </div>
            <br/><br/>
            <input type="submit" name="create_quiz" class="form-control btn btn-primary" value="Create Quiz">
        </form>
        </div>
    </body>
    <script type="text/javascript">
 
        $("#rowAdder").click(function () {

            newRowAdd = '<div id="row"><label for="answer_option"><b>Answer Option</b></label>'+
                        '<input type="text" name="answer_option[]" class="form-control m-input" required>'+
                        '<br/>'+
                        '<label for="answer"><b>Is Correct Answer?</b></label> '+
                        '<input type="checkbox" id="check1" name="answer"> '+
                        '<button class="btn btn-danger"'+
                            'id="DeleteRow" type="button">'+
                            '<i class="bi bi-trash"></i>'+
                                'Delete'+
                            '</button><br/></div>';

            // newRowAdd =
            
            // '<div id="row"> <div class="input-group m-3">' +
            // '<div class="input-group-prepend">' +
            // '<button class="btn btn-danger" id="DeleteRow" type="button">' +
            // '<i class="bi bi-trash"></i> Delete</button> </div>' +
            // '<input type="text" class="form-control m-input">'+
            // '<input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"> </div> </div>';
 
            $('#newinput').append(newRowAdd);
        });
 
        $("body").on("click", "#DeleteRow", function () {
            $(this).parents("#row").remove();
        });

        $("#course_selection").change(function(){
            console.log("Reached");
            var course_id = $(this).val();
            self.location.href = "create_quiz.php?course_id="+course_id;
        });
        
    </script>
</html>