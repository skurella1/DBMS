<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }

    session_unset();
    session_destroy();
    header("Location: ../common/index.php");
?>