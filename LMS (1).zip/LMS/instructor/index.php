<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link type="stylesheet" href="../styles/common_layout.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    
    <title>LMS - Instructor</title>
</head>
<script type="text/javascript" src="../scripts/course_view.js"></script>
<body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Signed in as <?php echo $_SESSION['teacher_name']; ?></h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="create_course.php">Add a new Course</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="create_course_content.php">Add Content for Course</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="create_quiz_item.php">Add Quiz for Course Content</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="instructor_logout.php">Logout</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
    <div class="container">
    <div class="grid-list-option">
        <p>View as:</p>
        <button class="btn" id="list-view" onclick="listView()"><i class="fa fa-bars"></i> List</button>
        <button class="btn" id="grid-view" onclick="gridView()"><i class="fa fa-th-large"></i> Grid</button>
    </div>
    <br/><br/>
    <?php
    
            if($connect)
            {
                $teacher_id = $_SESSION['teacher_id'];
                $sql_courses_teacher = "SELECT * FROM `courses` WHERE `created_by_teacher_id` = '$teacher_id'";
                $result_courses = mysqli_query($connect, $sql_courses_teacher);
                if($result_courses)
                {

                    if(mysqli_num_rows($result_courses) > 0)
                    {

                        echo "<div class='grid-container' >";
                        $row_count = 0;

                        for($i = 0; $i < mysqli_num_rows($result_courses); $i++)
                        {
                            if($i % 3 == 0)
                            {
                                echo "<div class='row' >";
                                $row_count++;
                            }
                            $row = mysqli_fetch_assoc($result_courses);
                            echo "<div class='column' style='padding:10px'>";
                            echo "<div class='card' style='padding:7px'>";
                            echo "<img src='".$row['course_image']."' class='card-img-top img-fluid' alt='Course Image' >";
                            echo "<h3><a href='course_view.php?course_id=".$row['course_id']."'>".$row['course_name']."</a></h3>";
                            echo "<p>".$row['course_desc']."</p>";
                            echo "<p>Price: ".$row['course_price']."</p>";
                            echo "<p>Discount Price: ".$row['course_discount_price']."</p>";
                            echo "<p>Start Date: ".$row['course_start_date']."</p>";
                            echo "<p>End Date: ".$row['course_end_date']."</p>";
                            echo "<p>Created by: ".$_SESSION['teacher_name']."</p>";
                            echo "<p><a href='edit_course.php?course_id=".$row['course_id']."'>Edit</a></p>";
                            echo "<p><a href='delete_course.php?course_id=".$row['course_id']."'>Delete</a></p>";
                            echo "</div>";
                            echo "</div>";
                            if($i % 3 == 2)
                            {
                                echo "</div>";
                            }
                        }
                        echo "</div>";

                    }
                    else
                    {
                        echo "<p>No courses found!</p>";
                    }
                }
                else
                {
                    echo "<p>Error: ".mysqli_error($connect)."</p>";
                }
            }
            else
            {
                echo "<p>Connection failed!</p>";
            }
    ?>
    </div>
</body>
</html>