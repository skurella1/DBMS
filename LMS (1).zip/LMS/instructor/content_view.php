<?php
    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }
    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['content_id']))
    {
        header("Location: course_view.php");
    }

    function get_particular_content($content_id)
    {
        global $connect;
        $sql = "SELECT * FROM `course_content` WHERE `content_id` = '$content_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $content = mysqli_fetch_assoc($result);
                $content_id = $content['content_id'];
                $content_name = $content['content_name'];
                $content_desc = $content['theory_notes'];
                $is_content_for_free = $content['is_content_available_for_free_access'];
                $content_video = $content['content_video_material'];
                $course_id = $content['associated_with_course'];
                ?>
                <div class="content-view-container">
                    <div class="content-view-details card container px-4" style="width: 40%;float: left;">
                        <div class="row gx-5">
                            <video width="100%" height="250px" controls>
                                <source src="<?php echo $content_video; ?>" type="video/mp4">
                                <source src="<?php echo $content_video; ?>" type="video/mov">
                            </video>
                        <h2><?php echo $content_name; ?></h2>
                        <p>
                            <a href="view_quiz.php?content_id=<?php echo $content_id; ?>" class="btn btn-secondary"><font color="white"><i class="fa fa-book">  View Quiz</font></i></a>
                            <a href="edit_content.php?content_id=<?php echo $content_id; ?>" class="btn btn-primary"><font color="white"><i class="fa fa-pencil">  Edit Content</font></i></a>
                            <a href="javascript:delete_confirmation(<?php echo $content_id; ?>, <?php echo $course_id;?>)" class="btn btn-danger"><font color="white"><i class="fa fa-trash">  Delete Content</i></font></a>
                        </p>
                        </div>
                    </div>
                    <div class="content-view-theory card container px-4" style="width: 40%;float: right;">
                        <div class="theory-notes ">
                            <h3>Theory Notes</h3>
                            <p><?php echo $content_desc; ?></p>
                        </div>
                    </div>
                </div>
                <?php
            }
            else
            {
                echo "No content found";
            }
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
    <title>LMS - Content View</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript">
        function delete_confirmation(content_id, course_id)
        {
            var confirmation = confirm("Are you sure you want to delete this content?");
            if(confirmation)
            {
                window.location.href = "delete_content.php?content_id="+content_id+"&course_id="+course_id;
            }
        }
    </script>
</head>
<body>
<header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>View Course Content</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back To Dashboard</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
    <div class="container">
    <?php get_particular_content($_GET['content_id']); ?>
    </div>
</body>
</html>