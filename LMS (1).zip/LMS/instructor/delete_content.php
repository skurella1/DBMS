<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }
    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['content_id']) && !isset($_GET['course_id']))
    {
        header("Location: course_view.php");
    }

    $content_id = $_GET['content_id'];
    // $quiz_id = 0;
    // $quiz_id = get_content_quiz_id($content_id);

    $sql = "DELETE FROM `course_content` WHERE `content_id` = '$content_id'";
    $result = mysqli_query($connect, $sql);
    if($result)
    {
        header("Location: course_view.php?course_id=".$_GET['course_id']);
        echo "<script>alert('Content Deleted Successfully!');</script>";
        
    }
    else
    {
        echo "<script>alert('Error Deleting Content!');</script>";
        echo "Error: ".mysqli_error($connect);
    }
    //delete content from course_content table
    if(delete_quiz_first($content_id))
    {
        
    }

    function get_content_quiz_id($content_id)
    {
        global $connect;
        $sql = "SELECT `quiz_id` FROM `course_content` WHERE `content_id` = '$content_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $row = mysqli_fetch_assoc($result);
                return $row['quiz_id'];
            }
            else
            {
                echo "<h2>No Quiz Found!</h2>";
            }  
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function delete_quiz_first($content_id)
    {
        global $connect;
        $sql = "DELETE FROM `course_content_quiz` WHERE `asscociated_with_course_content` = '$content_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return true;
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function delete_quiz_question($quiz_id)
    {
        global $connect;
        $sql = "DELETE FROM `quiz_question` WHERE `associated_quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return true;
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function delete_quiz_answers($quiz_id)
    {
        global $connect;
        $sql = "DELETE FROM `quiz_answer` WHERE `associated_quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return true;
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

?>