<!DOCTYPE html> 
<html>
<head>
    <title>LMS - Create Course Content</title>
    <link type="stylesheet" href="../styles/common_layout.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript">
        function delete_confirmation(content_id, course_id)
        {
            var confirmation = confirm("Are you sure you want to delete this content?");
            if(confirmation)
            {
                window.location.href = "delete_content.php?content_id="+content_id+"&course_id="+course_id;
            }
        }
    </script>
</head>
<body>
<header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Create Course</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back To Dashboard</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
    <div class="container">
<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }
    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(isset($_GET['course_id']))
    {
        $course_id = $_GET['course_id'];
        get_course_detail($course_id);
        get_course_contents($course_id);
    }
    else
    {
        header("Location: index.php");
    }

    function get_course_detail($course_id)
    {   
        global $connect;
        $sql_course_detail = "SELECT * FROM `courses` WHERE `course_id` = '$course_id' AND `created_by_teacher_id` = '".$_SESSION['teacher_id']."'";
        $result_course_detail = mysqli_query($connect, $sql_course_detail);



        if($result_course_detail)
        {
            if(mysqli_num_rows($result_course_detail) > 0)
            {
                $course_detail = mysqli_fetch_assoc($result_course_detail);
                $course_name = $course_detail['course_name'];
                $course_description = $course_detail['course_desc'];
                $course_price = $course_detail['course_price'];
                $course_disc_price = $course_detail['course_discount_price'];
                $course_start_date = $course_detail['course_start_date'];
                $course_end_date = $course_detail['course_end_date'];
                $course_image = $course_detail['course_image'];
                $course_teacher_id = $course_detail['created_by_teacher_id'];
                ?>
                <div class="course-view-container card container px-4" style="width: 50%;float: left;">
                    <div class="row gx-5">
                    <div class="course-view-image">
                        <img src="<?php echo $course_image; ?>" class='img-thumbnail' alt="Course Image">
                    </div>
                    <div class="course-view-details">
                        <h2><?php echo $course_name; ?></h2>
                        <p><?php echo $course_description; ?></p>
                        <p>Price: <?php echo $course_price; ?></p>
                        <p>Discounted Price: <?php echo $course_disc_price; ?></p>
                        <p>Start Date: <?php echo $course_start_date; ?></p>
                        <p>End Date: <?php echo $course_end_date; ?></p>
                    </div>
                    
                    <p> Edit Course Details <a class="btn btn-primary" href="edit_course.php?course_id=<?php echo $course_id; ?>"><i class="fa fa-pencil"></i>  Edit</a></p>
                    </div>
                </div>
        <?php
            }
            else
            {
                echo "<p>No courses found!</p>";
            }
        }
        else
        {
            echo "<p>Error: ".mysqli_error($connect)."</p>";
        }
    }

    function get_course_contents($course_id)
    {
        global $connect;
        $sql_course_contents = "SELECT * FROM `course_content` WHERE `associated_with_course` = '$course_id'";
        $result_course_contents = mysqli_query($connect, $sql_course_contents);

        if($result_course_contents)
        {
            if(mysqli_num_rows($result_course_contents) > 0)
            {
                while($row = mysqli_fetch_assoc($result_course_contents))
                {
                    $content_id = $row['content_id'];
                    $content_name = $row['content_name'];
                    $content_url = $row['content_video_material'];

                    $content_description = $row['theory_notes'];
                    ?>
                    
                    <div class="course-content-container card container px-4" style="width: 40%; margin-bottom:1%;float: right;">
                        <div class="row gx-5">
                            <div class="col">
                            <div class="course-content-image">
                                <video width="120px" height="120px">
                                    <source src="<?php echo $content_url; ?>" type="video/mp4">
                                    <source src="<?php echo $content_url; ?>" type="video/mov">
                                </video>
                            </div>
                            <div class="course-content-details">
                            <a href="content_view.php?content_id=<?php echo $content_id; ?>" ><h2><?php echo $content_name; ?></h2></a>
                                <p><?php echo $content_description; ?></p>
                                <p><a href="edit_content.php?content_id=<?php echo $content_id; ?>"><i class="fa fa-pencil"></i>  Edit Content</a> 
                                <a href="javascript:delete_confirmation(<?php echo $content_id; ?>, <?php echo $course_id;?>)"><font color='red'><i class="fa fa-trash"></i>Delete Content</a></font></p>
                            </div>
                            </div>
                        </div>
                    </div>
            <?php
                }
            }
            else
            {
                echo "<p>No contents found!</p>";
            }
        }
        else
        {
            echo "<p>Error: ".mysqli_error($connect)."</p>";
        }
    }

?>
    </div>

</body>
</html>