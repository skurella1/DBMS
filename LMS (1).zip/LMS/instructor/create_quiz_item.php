<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }
    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }
    $_SESSION['course_id'] = 0; 
    $teacher_id = $_SESSION['teacher_id'];

    if(isset($_POST['create_quiz']))
    {
        create_quiz_for_content();
    }

    function get_course_name()
    {
        global $connect;
        $teacher_id = $_SESSION['teacher_id'];
        $sql = "SELECT `course_name`, `course_id` FROM `courses` WHERE `created_by_teacher_id` = '$teacher_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return $result;
        }
        else
        {
            return "Error: ".mysqli_error($connect);
        }
    }

    function get_content_name($course_id)
    {
        global $connect;
        $sql = "SELECT `content_name`, `content_id` FROM `course_content` WHERE `associated_with_course` = '".$course_id."'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            // create a select box with the content names
            echo "<select name='content_id' class='form-control' required>";
            echo "<option>Select Course Content</option>";
            while($row = mysqli_fetch_assoc($result))
            {
                echo "<option value='".$row['content_id']."'>".$row['content_name']."</option>";
            }
            echo "</select>";
            

        }
        else
        {
            return "Error: ".mysqli_error($connect);
        }
    }

    function create_quiz_for_content()
    {
        if(isset($_POST['course_id']) && isset($_POST['content_id']))
        {
            global $connect;
            $course_id = $_POST['course_id'];
            $content_id = $_POST['content_id'];
            $sql = "INSERT INTO `course_content_quiz`(`is_active`, `asscociated_with_course_content`) VALUES ('1', '$content_id')";
            $result = mysqli_query($connect, $sql);
            if($result)
            {
                $sql = "SELECT `quiz_id` FROM `course_content_quiz` ORDER BY `quiz_id` DESC LIMIT 1";
                $result = mysqli_query($connect, $sql);
                if($result)
                {
                    $row = mysqli_fetch_assoc($result);
                    $quiz_id = $row['quiz_id'];
                    echo '<script>
                            alert("Created Quiz successfully!");
                            window.location.href = "create_quiz.php?quiz_id='.$quiz_id.'";
                        </script>';
                }
                else
                {
                    echo "Error: ".mysqli_error($connect);
                }
            }
            else
            {
                echo "<script>alert('Error Creating Quiz!');</script>";
            }
        }
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>LMS - Create QUIZ</title>
        <link type="stylesheet" href="../styles/common_layout.css">
        <link type="stylesheet" href="../styles/styles.css">
        <script src="../tinymce/tinymce.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script type="text/javascript" src="../scripts/text_editor.js"></script>
        <script type="text/javascript" src="../scripts/image_preview.js"></script>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    </head>
    <body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Create Quiz</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back To Dashboard</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
    <div class="container">
    
    <br/>
    <h2> Create Quiz </h2>
    <form action="create_quiz_item.php" method="post" enctype="multipart/form-data">
            <label for="course_id" class="form-label"><b>Associated with Course</b></label>
            <select name="course_id" class="form-control" id="course_selection" required>
                <option>Select Course</option>
                <?php
                    $result = get_course_name();
                    if($result)
                    {
                        
                        while($row = mysqli_fetch_assoc($result))
                        {
                            
                            if($_GET['course_id'] == $row['course_id'])
                            {
                                echo "selected";
                                echo "<option value='".$row['course_id']."' selected>".$row['course_name']."</option>";
                            }
                            else
                            {
                                echo "<option value='".$row['course_id']."'>".$row['course_name']."</option>";
                            }
                        }
                    }
                    else
                    {
                        echo $result;
                    }
                ?>
            </select>
            <br/><br/>
            <label for="course_id" class='form-label'><b>Associated with content</b></label>
            <?php

                if(isset($_GET['course_id']))
                {
                    $crse_id = $_GET['course_id'];
                    $_SESSION['course_id'] = $crse_id;
                    get_content_name($crse_id);
                }
                else
                {
                    echo "<select name='content_id' class='form-control' required>";
                    echo "<option>Select Course Content</option>";
                    echo "</select>";
                }
            
            ?>
            <br/><br/>
            <input type="submit" name="create_quiz" class="btn btn-primary" value="Create Quiz">
    </form>
    </div>
    </div>
    </body>
    <script type="text/javascript">
        $("#course_selection").change(function(){
            console.log("Reached");
            var course_id = $(this).val();
            self.location.href = "create_quiz_item.php?course_id="+course_id;
        });
    </script>
</html>