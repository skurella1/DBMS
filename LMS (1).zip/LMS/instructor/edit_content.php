<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    include_once('../common/file_upload_functions.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "<h3><font color=red>Database connection failed!</font></h3>";
        echo "<p>Error: ".mysqli_connect_error()."</p>";
    }

    if(!isset($_GET['content_id']))
    {
        header("Location: course_view.php");
    }

    $content_id = $_GET['content_id'];

    if(isset($_POST['edit_content']))
    {
        update_content_detail($_POST['content_id']);
    }

    function update_content_detail($content_id)
    {
        global $connect;
        if(isset($_FILES['content_video']) && !empty($_FILES['content_video']['name']))
        {
            $file_name = $_FILES['content_video']['name'];
            $file_tmp_name = $_FILES['content_video']['tmp_name'];
            $file_size = $_FILES['content_video']['size'];
            $file_error = $_FILES['content_video']['error'];
            $file_type = $_FILES['content_video']['type'];
            $file_destination = upload_content_video($file_name, $file_tmp_name, $file_size, $file_error, $file_type);
            if($file_destination == "error")
            {
                echo "<h3><font color=red>Error uploading file!</font></h3>";
                echo "<p>Cannot Edit content!</p>";
            }    
            else
            {
                $content_name = $_POST['content_name'];
                $content_description = $_POST['theory_notes'];
                $associated_course = $_POST['course_id'];
                $is_content_for_free = isset($_POST['is_free']) ? 1 : 0;
                $sql = "UPDATE `course_content` SET `content_name`='$content_name',`theory_notes`='$content_description',
                        `associated_with_course`='$associated_course',`content_video_material`='$file_destination', 
                        `is_content_available_for_free_access` = '$is_content_for_free' WHERE `content_id`='$content_id'";
                $result = mysqli_query($connect, $sql);
                if($result)
                {
                    echo "<font color='green'><p>Content updated successfully!</p></font>";
                }
                else
                {
                    echo "<font color='red'><p>Content updation failed!</p></font>";
                    echo "<p>Error: ".mysqli_error($connect)."</p>";
                }
            }
        }
        else
        {
            $content_name = $_POST['content_name'];
            $content_description = $_POST['theory_notes'];
            $associated_course = $_POST['course_id'];
            $is_content_for_free = isset($_POST['is_free']) ? 1 : 0;
            $sql = "UPDATE `course_content` SET `content_name`='$content_name',`theory_notes`='$content_description',
                    `associated_with_course`='$associated_course',
                    `is_content_available_for_free_access` = '$is_content_for_free' WHERE `content_id`='$content_id'";
            $result = mysqli_query($connect, $sql);
            if($result)
            {
                echo "<font color='green'><p>Content updated successfully!</p></font>";
            }
            else
            {
                echo "<h3><font color=red>Database query failed!</font></h3>";
                echo "<p>Error: ".mysqli_error($connect)."</p>";
            }
        }
    }

    function get_particular_content($content_id)
    {
        global $connect;
        $sql = "SELECT * FROM `course_content` WHERE `content_id` = '$content_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $content = mysqli_fetch_assoc($result);
                $content_id = $content['content_id'];
                $content_name = $content['content_name'];
                $content_desc = $content['theory_notes'];
                $is_content_for_free = $content['is_content_available_for_free_access'];
                $content_video = $content['content_video_material'];
                $associated_course = $content['associated_with_course'];
                ?>
                <form action="edit_content.php?content_id=<?php echo $content_id;?>" method="post" enctype="multipart/form-data">
                    <label for="content_name" class="form-label">Content Name</label>
                    <input type="text" class="form-control" name="content_name" id="content_name" value="<?php echo $content_name; ?>" required>
                    <br/><br/>
                    <label for="content_video" class="form-label">Course Video Material</label>
                    <input type="file" class="form-control" name="content_video" id="content_video" >
                    <br/><br/>
                    <video width="420px" height="220px" controls>
                        <source src="<?php echo $content_video; ?>" type="video/mp4" id="preview-image">
                        <source src="<?php echo $content_video; ?>" type="video/mov" id="preview-image">
                    </video>
                    <br/><br/>
                    <label for="is_free" class="form-label">Can freely accessed?</label>
                    <input type="checkbox" value="<?php echo $is_content_for_free; ?>" name="is_free" id="is_free">
                    <br/><br/>
                    <label for="theory_notes" class="form-label">Theory Notes</label>
                    <textarea rows = "5" cols = "60" name = "theory_notes" id="text-editor" class="form-control"><?php echo $content_desc; ?></textarea>
                    <br/><br/>
                    <label for="course_id" class="form-label">Associated With Course</label>
                    <select name="course_id" class="form-control">
                    <?php

                        $courses = get_courses_of_teacher($_SESSION['teacher_id']);
                        for($i=0;$i<mysqli_num_rows($courses);$i++)
                        {
                            $course = mysqli_fetch_assoc($courses);
                            if($course['course_id'] == $associated_course)
                            {
                                ?>
                                <option value="<?php echo $course['course_id']; ?>" selected><?php echo $course['course_name']; ?></option>
                                <?php
                            }
                            else
                            {
                                ?>
                                <option value="<?php echo $course['course_id']; ?>"><?php echo $course['course_name']; ?></option>
                                <?php
                            }
                        }
                    ?>
                    </select>
                    <br/><br/>
                    <input type="hidden" name="content_id" value="<?php echo $content_id;?>">
                    <input type="submit" class="form-control btn btn-primary" name="edit_content" value="Add Content">
                </form> 
                <?php
            }
            else
            {
                echo "No content found";
            }
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function get_courses_of_teacher($teacher_id)
    {
        global $connect;
        $sql = "SELECT `course_name`, `course_id` FROM `courses` WHERE `created_by_teacher_id` = '$teacher_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return $result;
        }
        else
        {
            echo "<p>Error: ".mysqli_error($connect)."</p>";
            return "error";
        }
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>LMS - Edit Content</title>
    <link type="stylesheet" href="../styles/common_layout.css">
    <script src="../tinymce/tinymce.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="../scripts/text_editor.js"></script>
    <script type="text/javascript" src="../scripts/image_preview.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Edit Course Content</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back To Dashboard</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
    <div class="container">
    <?php
        get_particular_content($content_id);
    ?>
    </div>
</body>
</html>
