<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    include_once('../common/file_upload_functions.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "<h3><font color=red>Database connection failed!</font></h3>";
        echo "<p>Error: ".mysqli_connect_error()."</p>";
    }

    if(!isset($_GET['course_id']))
    {
        header("Location: index.php");
    }

    $course_id = $_GET['course_id'];

    if(isset($_POST['edit_course']))
    {
        update_course_detail($_POST['course_id']);
    }

    function update_course_detail($course_id)
    {
        global $connect;
        if(isset($_FILES['course_image']) && !empty($_FILES['course_image']['name']))
        {
            $file_name = $_FILES['course_image']['name'];
            $file_tmp_name = $_FILES['course_image']['tmp_name'];
            $file_size = $_FILES['course_image']['size'];
            $file_error = $_FILES['course_image']['error'];
            $file_type = $_FILES['course_image']['type'];
            $file_destination = upload_course_thumbnail($file_name, $file_tmp_name, $file_size, $file_error, $file_type);
            if($file_destination == "error")
            {
                echo "<h3><font color=red>Error uploading file!</font></h3>";
                echo "<p>Cannot create course!</p>";
            }    
            else
            {
                $course_name = $_POST['course_name'];
                $course_description = $_POST['course_description'];
                $course_price = $_POST['course_price'];
                $course_disc_price = $_POST['course_disc_price'];
                $course_start_date = $_POST['course_start_date'];
                $course_end_date = $_POST['course_end_date'];
                $course_teacher_id = $_SESSION['teacher_id'];

                $sql = "UPDATE `courses` SET `course_name`='$course_name',`course_desc`='$course_description',
                        `course_price`='$course_price',`course_discount_price`='$course_disc_price',
                        `course_start_date`='$course_start_date',`course_end_date`='$course_end_date',
                        `course_image`='$file_destination' WHERE `course_id`='$course_id' AND `created_by_teacher_id` = '$course_teacher_id'";
                $result = mysqli_query($connect, $sql);
                if($result)
                {
                    echo "<font color='green'><p>Course updated successfully!</p></font>";
                }
                else
                {
                    echo "<font color='red'><p>Course updation failed!</p></font>";
                    echo "<p>Error: ".mysqli_error($connect)."</p>";
                }
            }
        }
        else
        {
            $course_name = $_POST['course_name'];
            $course_description = $_POST['course_description'];
            $course_price = $_POST['course_price'];
            $course_disc_price = $_POST['course_disc_price'];
            $course_start_date = $_POST['course_start_date'];
            $course_end_date = $_POST['course_end_date'];
            $course_teacher_id = $_SESSION['teacher_id'];
            $course_image_path = $_POST['existing_image'];

            $sql = "UPDATE `courses` SET `course_name`='$course_name',`course_desc`='$course_description',
                    `course_price`='$course_price',`course_discount_price`='$course_disc_price',
                    `course_start_date`='$course_start_date',`course_end_date`='$course_end_date',
                    `course_image`='$course_image_path' WHERE `course_id`='$course_id' AND `created_by_teacher_id` = '$course_teacher_id'";
            $result = mysqli_query($connect, $sql);
            if($result)
            {
                echo "<font color='green'><p>Course updated successfully!</p></font>";
            }
            else
            {
                echo "<font color='red'><p>Course updation failed!</p></font>";
                echo "<p>Error: ".mysqli_error($connect)."</p>";
            }
        }
        
    }

    function get_course_detail($course_id)
    {   
        global $connect;
        $sql_course_detail = "SELECT * FROM `courses` WHERE `course_id` = '$course_id' AND `created_by_teacher_id` = '".$_SESSION['teacher_id']."'";
        $result_course_detail = mysqli_query($connect, $sql_course_detail);



        if($result_course_detail)
        {
            if(mysqli_num_rows($result_course_detail) > 0)
            {
                $course_detail = mysqli_fetch_assoc($result_course_detail);
                $course_name = $course_detail['course_name'];
                $course_description = $course_detail['course_desc'];
                $course_price = $course_detail['course_price'];
                $course_disc_price = $course_detail['course_discount_price'];
                $course_start_date = $course_detail['course_start_date'];
                $course_end_date = $course_detail['course_end_date'];
                $course_start_date = date('Y-m-d', strtotime($course_start_date));
                $course_end_date = date('Y-m-d', strtotime($course_end_date));
                $course_image = $course_detail['course_image'];
                $course_teacher_id = $course_detail['created_by_teacher_id'];
                ?>
                <form action="edit_course.php?course_id=<?php echo $course_id; ?>" method="post" enctype="multipart/form-data">
                    <label for="course_name" class="form-label">Course Name</label>
                    <input type="text" name="course_name" id="course_name" value="<?php echo $course_name;?>" required>
                    <br/><br/>
                    <label for="course_description" class="form-label">Course Description</label>
                    <textarea rows = "5" cols = "60" class="form-control" name = "course_description" id="text-editor">
                        <?php echo $course_description;?>
                    </textarea>
                    <br/><br/>
                    <label for="course_image" class="form-label">Course Thumbnail</label>
                    <input type="file" class="form-control" name="course_image" id="course_image" onchange="readURL(this);">
                    <br/><br/>
                    <img id="preview-image" class="img-thumbnail" src="<?php echo $course_image; ?>" width="200px" height="200px">
                    <br/><br/>
                    <label for="course_price" class="form-label">Course Price</label>
                    <input type="number" class="form-control" name="course_price" id="course_price" value="<?php echo $course_price; ?>" required>
                    <br/><br/>
                    <label for="course_price" class="form-label">Course Discounted Price</label>
                    <input type="number" class="form-control" name="course_disc_price" id="course_disc_price" value="<?php echo $course_disc_price;?>" required>
                    <br/><br/>
                    <label for="course_start_date" class="form-label">Course Start Date</label>
                    <input type="date" class="form-control" name="course_start_date" id="course_start_date" value="<?php echo $course_start_date;?>" required>
                    <br/><br/>
                    <label for="course_end_date" class="form-label">Course End Date</label>
                    <input type="date" class="form-control" name="course_end_date" id="course_end_date" value="<?php echo $course_end_date;?>" required>
                    <br/><br/>
                    <input type="hidden" name="existing_image" value="<?php echo $course_image; ?>">
                    <input type="hidden" name="course_id" value="<?php echo $course_id;?>">
                    <input type="hidden" name="teacher_id" value="<?php echo $course_teacher_id;?>">
                    <input type="submit" class="form-control btn btn-primary" name="edit_course" value="Edit Course">
                </form>
        <?php
            }
            else
            {
                echo "<p>No courses found!</p>";
            }
        }
        else
        {
            echo "<p>Error: ".mysqli_error($connect)."</p>";
        }
    }


?>


<!DOCTYPE html>
<html>
<head>
    <title>LMS - Edit Course</title>
    <link type="stylesheet" href="../styles/common_layout.css">
    <script src="../tinymce/tinymce.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="../scripts/text_editor.js"></script>
    <script type="text/javascript" src="../scripts/image_preview.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Edit Course</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back To Dashboard</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
    <div class="container">
    <?php
        get_course_detail($course_id);
    ?>
    </div>
    

</body>
</html>